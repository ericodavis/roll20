For instructions, note the "Instruction" tab on the spreadsheet!

The spreadsheet is the #1 file. This is protected to prevent accidental
corruption of the spreadsheet. Generally, you use the save and load macro
buttons at the top of the spreadsheet to save your character data. This
is really important if you customize the sheet (else you have to "edit"
every characters sheet - a real drag). Many people just save the whole
spreadsheet instead - that works fine if you never customize the sheets.

The #2 file is a spreadsheet disguised as a different file. It is not
meant to be used by itself. If you use the save and load buttons, then
it's very helpful to have a "blank" sheet to clear your data. That's
what #2 is for.